import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export interface Post {
  id: string;
  user: string;
  link: string;
  time: Date;
}

export interface UserStat {
  username: string;
  points: number;
}

export interface InviteData {
  userId: string;
  username: string;
  inviteCount: number;
}

export const insertPostSchema = z.object({
  user: z.string(),
  link: z.string().url(),
});

export type InsertPost = z.infer<typeof insertPostSchema>;
