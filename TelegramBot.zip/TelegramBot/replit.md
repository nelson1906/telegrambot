# NEAR 9ja Engagement Bot

A Telegram bot designed to gamify and track community engagement for the NEAR 9ja community. Members can share NEAR-related posts, engage with others' content, and compete on a leaderboard with weekly resets and winner announcements.

## Overview

This bot helps build an active, engaged NEAR community by:
- Tracking shared posts and content
- Rewarding members with points for engagement
- Maintaining a competitive leaderboard
- Announcing weekly champions with automatic resets
- Tracking referral invites with personal invite links
- Dual leaderboard system: engagement points and invite counts

## Features

### Core Commands
- `/start` - Welcome message with command overview
- `/drop <link>` - Share a NEAR-related post
- `/engage` - View the 5 most recent community posts
- `/leaderboard` - See top 10 engagers
- `/stats` - Check your personal engagement points
- `/help` - Learn how the bot works
- `/addpoints @username <points>` - Admin command to award points

### Invite Tracking Commands
- `/getlink` - Get your personal invite link to share
- `/invites` - View the top 10 inviters leaderboard
- `/myinvites` - Check how many people you've invited

### Weekly Reset System
Every Sunday at 8PM, the bot automatically:
1. Announces the top 3 winners with medals (🥇🥈🥉)
2. Posts to the configured group chat
3. Resets all stats for the new week

## Configuration

### Required Environment Variables
- `BOT_TOKEN` - Your Telegram bot token from @BotFather (Required)
- `BOT_USERNAME` - Your bot's username without @ symbol (Required for invite links)
- `GROUP_CHAT_ID` - Telegram group chat ID for weekly announcements (Optional)

### Getting Your Bot Token
1. Open Telegram and search for @BotFather
2. Send `/newbot` and follow the instructions
3. Copy the token provided
4. Add it to Replit Secrets as `BOT_TOKEN`

### Getting Your Group Chat ID
1. Add your bot to your Telegram group
2. Send a message in the group
3. Visit: `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates`
4. Look for `"chat":{"id":-123456789` in the response
5. Add the chat ID to Replit Secrets as `GROUP_CHAT_ID`

## Technical Stack

### Backend
- **Node.js** with TypeScript
- **Express.js** server
- **node-telegram-bot-api** for Telegram integration
- **In-memory storage** for posts and leaderboard data

### Storage
Currently using in-memory storage (MemStorage) which persists data while the server is running. For production use with long-term persistence, consider migrating to PostgreSQL database.

## Project Structure

```
server/
  ├── bot.ts          # Telegram bot logic and command handlers
  ├── storage.ts      # Data storage interface and in-memory implementation
  ├── routes.ts       # Express API routes (currently minimal)
  └── index.ts        # Server entry point

shared/
  └── schema.ts       # TypeScript types for Post, UserStat, etc.

client/              # Frontend (minimal - bot is primary interface)
```

## Usage

### For Community Members
1. Find the bot on Telegram
2. Send `/start` to begin
3. Use `/drop` to share NEAR-related posts
4. Use `/engage` to see and interact with others' posts
5. Earn points by engaging (admins award points)
6. Compete on the `/leaderboard`
7. Get your invite link with `/getlink` and share it
8. Track your invites with `/myinvites`
9. Compete on the invite leaderboard with `/invites`

### For Admins
- Award points: `/addpoints @username 10`
- Monitor engagement through the leaderboard
- Weekly winners are announced automatically if GROUP_CHAT_ID is set
- Track community growth through the invite leaderboard

## Development

The bot automatically starts when the server runs. Check the console logs for:
- ✅ Bot connection status
- 📢 Weekly reset configuration
- 🤖 Bot startup messages

## Future Enhancements

Potential additions:
- Database persistence (PostgreSQL)
- Automatic engagement verification
- Post categories and filtering
- Custom reward tiers
- Integration with NEAR Protocol for token rewards
- NFT badge distribution

## Notes

- All data is currently stored in memory and resets when the server restarts
- Weekly reset runs every Sunday at 8PM (server time)
- Posts and stats persist between weekly resets unless server restarts
- The bot uses polling mode to receive updates from Telegram
