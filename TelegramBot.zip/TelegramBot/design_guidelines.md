# NEAR 9ja Telegram Bot - Design Guidelines

## Project Context
This is a **Telegram bot application** with no web-based frontend. All user interactions occur within the Telegram messaging platform through bot commands. Therefore, traditional web design guidelines (layouts, components, typography systems) do not apply.

## Design Constraints
The entire user experience is delivered through:
- Text-based messages within Telegram chat interface
- Telegram's native message formatting capabilities
- Emoji-enhanced content presentation
- Command-driven interactions

## Message Design Principles

### Visual Hierarchy in Text Messages
**Primary Information**: Use emojis as visual anchors (🏆, 🔥, ✅, 📊)
**Structured Data**: Format with consistent spacing and symbols
**User Mentions**: Always prefix with @ for clarity (@username)
**Links**: Display on separate lines for easy tapping

### Emoji Strategy
Use emojis purposefully and consistently:
- **Status indicators**: ✅ (success), ❌ (error), ⚠️ (warning)
- **Content categories**: 📎 (posts), 🔥 (engagement), 🏆 (leaderboard), 📊 (stats)
- **Brand identity**: 🇳🇬 (Nigeria), 👋 (welcome), ❓ (help)
- **Action prompts**: Use relevant emojis to make commands feel inviting

### Message Formatting Standards

**Welcome Messages**: Multi-line with clear command list
```
Greeting + Emoji
Brief introduction

Command List:
emoji /command – description
emoji /command – description
```

**Data Display**: Structured with consistent separators
```
Header with emoji
blank line
Item 1 with number/rank
Item 2 with number/rank
```

**Confirmation Messages**: Short, clear, with next-step guidance
```
Status emoji + Action confirmed
Details
Suggested next action
```

### Response Patterns

**Leaderboard Display**:
- Numbered ranking (1., 2., 3.)
- Username with @ prefix
- Point value with "pts" suffix
- Em dash separator for readability

**Post Listings**:
- User attribution line (👤 @username)
- Link on separate line (🔗 url)
- Double line breaks between entries

**Error Messages**:
- Start with ❌
- Clear explanation of what went wrong
- Provide correct usage example

## Content Tone
- **Enthusiastic**: Use exclamation points strategically, not excessively
- **Community-focused**: Emphasize collaboration ("engage with others")
- **Encouraging**: Celebrate participation and progress
- **Nigerian identity**: Maintain 🇳🇬 presence in welcome messaging

## No Web Frontend Required
This project has **no visual website, dashboard, or web interface**. All design considerations are limited to optimizing text-based message presentation within Telegram's messaging constraints.