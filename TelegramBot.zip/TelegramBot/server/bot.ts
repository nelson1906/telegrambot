import TelegramBot from 'node-telegram-bot-api';
import { storage } from './storage';

const token = process.env.BOT_TOKEN;

if (!token) {
  console.error('❌ BOT_TOKEN is not set in environment variables');
  console.error('Please add your Telegram bot token to Replit Secrets as BOT_TOKEN');
  process.exit(1);
}

export const bot = new TelegramBot(token, { polling: true });

console.log('🤖 NEAR 9ja Engagement Bot is starting...');

bot.onText(/\/start(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const firstName = msg.from?.first_name || 'there';
  const userId = msg.from?.id.toString() || '';
  const username = msg.from?.username || msg.from?.first_name || 'Anonymous';
  const ref = match?.[1]?.trim();

  await storage.registerUser(userId, username);

  if (ref && ref !== userId) {
    try {
      const inviteCount = await storage.addInvite(ref);
      await bot.sendMessage(ref, `🎉 Someone just joined NEAR 9ja using your link! You now have ${inviteCount} invites.`);
    } catch (error) {
      console.log('Failed to process referral:', error);
    }
  }
  
  await bot.sendMessage(chatId, 
    `Hey ${firstName}! 👋
Welcome to the NEAR 9ja Engagement Bot 🇳🇬

Use these commands to get started:
📎 /drop – Drop your NEAR-related post
🔥 /engage – See latest posts to engage with
🏆 /leaderboard – Check top engagers
📊 /stats – View your engagement stats
🔗 /getlink – Get your invite link
👥 /invites – See invite leaderboard
📈 /myinvites – Check your invites
❓ /help – Learn how this game works`
  );
});

bot.onText(/\/help/, async (msg) => {
  const chatId = msg.chat.id;
  
  await bot.sendMessage(chatId,
    `❓ How the NEAR 9ja Engagement Bot Works

📎 **Drop Your Posts**
Share your NEAR-related content using /drop followed by your link:
Example: /drop https://twitter.com/yourpost

🔥 **Engage with Others**
Use /engage to see the latest posts from the community. Like, comment, retweet, and engage!

🎯 **Earn Points**
Admins track engagement and award points for quality interactions. The more you engage, the more you earn!

🏆 **Climb the Leaderboard**
Check your ranking with /leaderboard and compete to be the top engager!

📊 **Track Your Progress**
Use /stats anytime to see your current points.

🔗 **Invite & Earn**
Get your personal invite link with /getlink and share it to grow the community!
Track your invites with /myinvites and see top inviters with /invites.

Let's grow the NEAR 9ja community together! 🇳🇬`
  );
});

bot.onText(/\/drop (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const user = msg.from?.username || msg.from?.first_name || 'anonymous';
  const link = match?.[1];

  if (!link) {
    await bot.sendMessage(chatId, '❌ Please provide a link. Usage: /drop <link>');
    return;
  }

  try {
    await storage.addPost({ user, link });
    await bot.sendMessage(chatId, 
      `✅ Post added by @${user}
🔗 ${link}

Now go engage with others using /engage`
    );
  } catch (error) {
    await bot.sendMessage(chatId, '❌ Failed to add post. Please make sure you provided a valid link.');
  }
});

bot.onText(/\/engage$/, async (msg) => {
  const chatId = msg.chat.id;
  
  try {
    const posts = await storage.getRecentPosts(5);
    
    if (posts.length === 0) {
      await bot.sendMessage(chatId, "No posts yet. Use /drop <link> to add one!");
      return;
    }

    const postList = posts
      .map(p => `👤 @${p.user}\n🔗 ${p.link}`)
      .join('\n\n');

    await bot.sendMessage(chatId, `🔥 Latest posts to engage with:\n\n${postList}`);
  } catch (error) {
    await bot.sendMessage(chatId, '❌ Failed to fetch posts. Please try again.');
  }
});

bot.onText(/\/leaderboard$/, async (msg) => {
  const chatId = msg.chat.id;
  
  try {
    const leaderboard = await storage.getLeaderboard(10);
    
    if (leaderboard.length === 0) {
      await bot.sendMessage(chatId, "No leaderboard data yet! Start engaging.");
      return;
    }

    const board = leaderboard
      .map((stat, i) => `${i + 1}. @${stat.username} — ${stat.points} pts`)
      .join('\n');

    await bot.sendMessage(chatId, `🏆 Top Engagers This Week:\n\n${board}`);
  } catch (error) {
    await bot.sendMessage(chatId, '❌ Failed to fetch leaderboard. Please try again.');
  }
});

bot.onText(/\/stats$/, async (msg) => {
  const chatId = msg.chat.id;
  const user = msg.from?.username || msg.from?.first_name || 'anonymous';
  
  try {
    const score = await storage.getUserStats(user);
    await bot.sendMessage(chatId, `📊 @${user}, you currently have ${score} points!`);
  } catch (error) {
    await bot.sendMessage(chatId, '❌ Failed to fetch stats. Please try again.');
  }
});

bot.onText(/\/addpoints (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const args = match?.[1]?.split(" ");
  
  if (!args || args.length < 2) {
    await bot.sendMessage(chatId, "❌ Invalid format. Use /addpoints @username 10");
    return;
  }

  const target = args[0].replace("@", "");
  const points = parseInt(args[1]);

  if (isNaN(points)) {
    await bot.sendMessage(chatId, "❌ Invalid format. Use /addpoints @username 10");
    return;
  }

  try {
    await storage.addPoints(target, points);
    await bot.sendMessage(chatId, `✅ Added ${points} pts to @${target}`);
  } catch (error) {
    await bot.sendMessage(chatId, '❌ Failed to add points. Please try again.');
  }
});

bot.onText(/\/getlink$/, async (msg) => {
  const userId = msg.from?.id.toString();
  const username = msg.from?.username || msg.from?.first_name || 'Anonymous';
  const botUsername = process.env.BOT_USERNAME;

  if (!botUsername) {
    await bot.sendMessage(msg.chat.id, '❌ Bot username not configured. Please contact the admin.');
    return;
  }

  if (userId) {
    await storage.registerUser(userId, username);
    const link = `https://t.me/${botUsername}?start=${userId}`;
    await bot.sendMessage(msg.chat.id, 
      `🔗 Your personal invite link:\n${link}\n\nShare this link to invite others and earn rewards!`
    );
  }
});

bot.onText(/\/invites$/, async (msg) => {
  const chatId = msg.chat.id;
  
  try {
    const leaderboard = await storage.getInviteLeaderboard(10);
    
    if (leaderboard.length === 0) {
      await bot.sendMessage(chatId, "No invites yet. Be the first to start inviting!");
      return;
    }

    const board = leaderboard
      .map((data, i) => `${i + 1}. ${data.username} — ${data.inviteCount} invites`)
      .join('\n');

    await bot.sendMessage(chatId, `🏆 Top Inviters 🏆\n\n${board}`);
  } catch (error) {
    await bot.sendMessage(chatId, '❌ Failed to fetch invite leaderboard. Please try again.');
  }
});

bot.onText(/\/myinvites$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from?.id.toString();
  const firstName = msg.from?.first_name || 'there';
  
  if (!userId) {
    await bot.sendMessage(chatId, '❌ Unable to identify user.');
    return;
  }

  try {
    const count = await storage.getUserInvites(userId);
    await bot.sendMessage(chatId, `👋 ${firstName}, you have invited ${count} people so far.`);
  } catch (error) {
    await bot.sendMessage(chatId, '❌ Failed to fetch your invites. Please try again.');
  }
});

bot.on('polling_error', (error) => {
  console.error('❌ Polling error:', error);
});

const groupChatId = process.env.GROUP_CHAT_ID;

if (groupChatId) {
  console.log(`📢 Weekly reset enabled for group chat: ${groupChatId}`);
  
  setInterval(async () => {
    const now = new Date();
    const day = now.getDay();
    const hour = now.getHours();

    if (day === 0 && hour === 20) {
      await announceWinners();
    }
  }, 60 * 60 * 1000);
} else {
  console.log('ℹ️  Weekly reset disabled (GROUP_CHAT_ID not set)');
}

async function announceWinners() {
  if (!groupChatId) return;

  try {
    const leaderboard = await storage.getLeaderboard(3);
    
    if (leaderboard.length === 0) {
      console.log('No stats to announce this week');
      return;
    }

    const medals = ['🥇', '🥈', '🥉'];
    const top3 = leaderboard
      .map((stat, i) => `${medals[i]} @${stat.username} — ${stat.points} pts`)
      .join('\n');

    const message = `🔥 *NEAR 9ja Weekly Champions!* 🔥\n\n${top3}\n\n🏆 Rewards in $NEAR + NFTs coming soon!\n\nNew week, new race! 🚀`;

    await bot.sendMessage(groupChatId, message, { parse_mode: 'Markdown' });
    
    await storage.resetAllStats();
    
    console.log('✅ Weekly winners announced and stats reset');
  } catch (error) {
    console.error('❌ Failed to announce winners:', error);
  }
}

console.log('✅ NEAR 9ja Engagement Bot is running!');
console.log('📱 You can now interact with your bot on Telegram');
