import { type User, type InsertUser, type Post, type InsertPost, type UserStat, type InviteData } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  addPost(post: InsertPost): Promise<Post>;
  getRecentPosts(limit: number): Promise<Post[]>;
  getAllPosts(): Promise<Post[]>;
  
  getUserStats(username: string): Promise<number>;
  addPoints(username: string, points: number): Promise<void>;
  getLeaderboard(limit: number): Promise<UserStat[]>;
  getAllUserStats(): Promise<UserStat[]>;
  resetAllStats(): Promise<void>;
  
  registerUser(userId: string, username: string): Promise<void>;
  addInvite(userId: string): Promise<number>;
  getUserInvites(userId: string): Promise<number>;
  getInviteLeaderboard(limit: number): Promise<InviteData[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private posts: Post[];
  private userStats: Map<string, number>;
  private invites: Map<string, number>;
  private userRegistry: Map<string, string>;

  constructor() {
    this.users = new Map();
    this.posts = [];
    this.userStats = new Map();
    this.invites = new Map();
    this.userRegistry = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async addPost(insertPost: InsertPost): Promise<Post> {
    const post: Post = {
      id: randomUUID(),
      user: insertPost.user,
      link: insertPost.link,
      time: new Date(),
    };
    this.posts.push(post);
    return post;
  }

  async getRecentPosts(limit: number): Promise<Post[]> {
    return this.posts.slice(-limit).reverse();
  }

  async getAllPosts(): Promise<Post[]> {
    return [...this.posts];
  }

  async getUserStats(username: string): Promise<number> {
    return this.userStats.get(username) || 0;
  }

  async addPoints(username: string, points: number): Promise<void> {
    const currentPoints = this.userStats.get(username) || 0;
    this.userStats.set(username, currentPoints + points);
  }

  async getLeaderboard(limit: number): Promise<UserStat[]> {
    const stats = Array.from(this.userStats.entries())
      .map(([username, points]) => ({ username, points }))
      .sort((a, b) => b.points - a.points)
      .slice(0, limit);
    return stats;
  }

  async getAllUserStats(): Promise<UserStat[]> {
    return Array.from(this.userStats.entries())
      .map(([username, points]) => ({ username, points }))
      .sort((a, b) => b.points - a.points);
  }

  async resetAllStats(): Promise<void> {
    this.userStats.clear();
  }

  async registerUser(userId: string, username: string): Promise<void> {
    this.userRegistry.set(userId, username);
  }

  async addInvite(userId: string): Promise<number> {
    const currentInvites = this.invites.get(userId) || 0;
    const newCount = currentInvites + 1;
    this.invites.set(userId, newCount);
    return newCount;
  }

  async getUserInvites(userId: string): Promise<number> {
    return this.invites.get(userId) || 0;
  }

  async getInviteLeaderboard(limit: number): Promise<InviteData[]> {
    const leaderboard = Array.from(this.invites.entries())
      .map(([userId, inviteCount]) => ({
        userId,
        username: this.userRegistry.get(userId) || userId,
        inviteCount,
      }))
      .sort((a, b) => b.inviteCount - a.inviteCount)
      .slice(0, limit);
    return leaderboard;
  }
}

export const storage = new MemStorage();
